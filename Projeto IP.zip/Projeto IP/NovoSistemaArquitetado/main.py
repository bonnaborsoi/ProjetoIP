import RodarJogo
RodarJogo.RodarJogo()