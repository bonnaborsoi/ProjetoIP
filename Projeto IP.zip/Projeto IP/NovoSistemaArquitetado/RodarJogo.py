import pygame as pg
pg.init()

from NovoSistemaArquitetado.Componentes.Janela.Dados import DadosJanela as DT
from NovoSistemaArquitetado import Montador as M
from NovoSistemaArquitetado.Componentes.Janela.Dados import DadosTelaFinal as DTF

StartGame = False

def RodarJogo():
    global StartGame
    # Loop do Jogo
    while DT.JanelaAberta:
        for evento in pg.event.get():
            #Para fechar a janela ao clicar no x
            if evento.type == pg.QUIT:
                DT.JanelaAberta = False
        if not StartGame:
            M.TelaInicial()
            for evento in pg.event.get():
                if evento.type == pg.KEYDOWN:
                    if evento.key == pg.K_ESCAPE and StartGame:
                        DT.JanelaAberta = False
                    if evento.type == pg.QUIT:
                        DT.JanelaAberta = False
                    if evento.key == pg.K_SPACE and not StartGame:
                        StartGame = True
        if StartGame:
            if not DTF.TelaFinal:
                M.Montar()
            if DTF.TelaFinal:
                M.TelaFinal()
                for evento in pg.event.get():
                    if evento.type == pg.KEYDOWN:
                        if evento.key == pg.K_ESCAPE and StartGame:
                            DT.JanelaAberta = False