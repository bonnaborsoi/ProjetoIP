import pygame as pg

Mapa = pg.image.load("Componentes/Mapa/Recursos/Mapa.png")
Mapa = pg.transform.scale(Mapa, (700, 630))