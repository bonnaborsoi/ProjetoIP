import pygame as pg

Fonte = pg.font.SysFont('Consolas', 20)
TextoSucesso = 'Você Conseguiu, Parabéns!'.rjust(3)
TextoDerrota = 'Não foi dessa vez, tente de novo!'.rjust(3)
TelaFinal = False
Sucesso = False
Derrota = False