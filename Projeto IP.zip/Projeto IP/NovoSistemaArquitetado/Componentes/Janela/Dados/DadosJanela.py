import pygame as pg
pg.init()

#Tamanho da Janela
LarguraJanela,AlturaJanela = 700,630

#Variável que Mantém a Janela Aberta
JanelaAberta = True

Icone = pg.image.load("Componentes/Janela/Recursos/Icone.png")