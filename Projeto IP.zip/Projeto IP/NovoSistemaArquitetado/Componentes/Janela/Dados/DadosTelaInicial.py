import pygame as pg

TelaInicial = pg.image.load("Componentes/Janela/Recursos/TitleScreen2.png")
TelaInicial = pg.transform.scale(TelaInicial, (700, 630))